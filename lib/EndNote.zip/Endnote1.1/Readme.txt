EndNote Export Filter for JabRef
version 1.1
2004-01-13

Written by Alex Montgomery (ahm@stanford.edu)

*********************************************************************************
Overview:
*********************************************************************************

The EndNote Export Filter for JabRef (when combined with the "EndNote Import from JabRef.enf" filter for EndNote, derived from the "EndNote Import" filter) allows for most of the default JabRef fields to be imported into the appropriate EndNote fields. Two export styles from EndNote ("BibTeX Export to JabRef") are also included that support the same fields. Note that the default EndNote Reference Types must be modified by the user to support the import of certain fields.

*********************************************************************************
Changes:
*********************************************************************************
1.1:	2005-01-13
	NOTE FOR UPGRADERS: YOU WILL NEED TO ADD ADDITIONAL FIELDS TO ENDNOTE'S DEFAULT REFERENCE TYPES TO SUPPORT THE NEW MAPPINGS.
	(Magazine Article, Newspaper Article, Edited Book, Electronic Source, Manuscript, Computer Program)
	See Installation below. You will only need to add fields to the above EndNote reference types.
	RefTypeTable.xml:
		Added so that Endnote 8 users don't have to modify their ReferenceTypes.
	BibTeX Export to JabRef:
		Bugfix: If Label was missing, entrytype line was deleted.
		Bugfix: Book Section mapped to inbook, now incollection.
		EndNoteRefType added to all output styles.
		Added ISBN/ISSN to export where appropriate.
		Output styles added: 
			Magazine Article -> article
			Newspaper Article -> article
			Edited Book -> book
			Electronic Source -> misc
			Manuscript -> unpublished
			Computer Program -> manual
	BibTeX Export to JabRef2:
		Same modifications as above. 
		Bugfix: File renamed to eliminate problems with Windows machines.
	EndNote.*.layout:
		Bugfix:	EndNote.techreport.layout did not export report number
		Updated to use EndNoteRefType field if it exists
		Updated to include ISBN/ISSN if it exists
		Layouts/New mappings added:
			unpublished -> Manuscript
			manual -> Computer Program
			booklet -> Personal Communication
				(\lastchecked field now mapped to Number field)

1.0: Initial version, 2004-12-02

*********************************************************************************
Installation:
*********************************************************************************
EndNote Import from JabRef.eni
This file must be placed in your EndNote Filters directory. On a Mac OS X system, the default directory is /Applications/EndNote 7/Filters. On a Windows XP system, the default directory is C:\Program Files\EndNote\Filters. The default EndNote Import filter will be able to import the files from JabRef, but supports fewer fields. You should then open up the Filter Manager (Edit->Import Filters->Open Filter Manager) and add it to your Favorites.

EndNote Preferences
The filter provided will only work properly if certain fields are added to EndNote's default Reference Types.

ENDNOTE 8:
RefTypeTable.xml:
If you are an EndNote 8 user, this file contains all of the modifications needed. WARNING: this will replace any customizations you may have already made.
On Windows XP, this file should be placed in C:\Documents and Settings\<user>\Application Data\EndNote\
On Mac OS X, ~/Library/Application Support/Endnote/

ENDNOTE 7:
Open up Preferences and click on Reference Types, then Modify Reference Types. The following table lists the field names that must be added to certain reference types for EndNote to support these fields. For example, the Publisher field for Journal Article is blank by default; Type in Publisher in this field. 

Tag	Generic Name 	New Field Name	Ref Types
%I	Publisher	Publisher	(Journal Article, Newspaper Article, Magazine Article)
%& 	Section		Section 	(Book Section)
%9 	Type of Work	Type of Work 	(Book Section)
%8 	Date		Date 		(Book, Book Section, Edited Book, Thesis, Computer Program)
%@	Number		Number		(Personal Communication)
%1 	Custom 1	pdf		(All)
%2 	Custom 2	comment		(All)
%3 	Custom 3	entrytype	(All)
%4 	Custom 4	crossref	(All)
%# 	Custom 5	owner		(All)
%$ 	Custom 6	key		(All)
(All = Journal Article, Book, Book Section, Manuscript, Edited Book, Magazine Article, Newspaper Article, Conference Proceedings, Thesis, Report, Personal Communication, Computer Program, Electronic Source)
(NB New for 1.1: Magazine Article, Newspaper Article, Edited Book, Electronic Source, Manuscript, Computer Program)

EndNote.*.layout:
These files must be kept together in a single directory.
Start JabRef. In the "Options" menu you will find the button "Manage custom exports". The "Manage custom exports" interface will appear. Click the "Add new" button. You can choose a name for the export filter (e.g. "EndNote"). Specify the location of the main layout file (which is the file "EndNote.layout") by typing the full path or by using the "Browse" button. The file extension should be set to ".txt" Click "OK". Now you will find the new custom export filter in the "File" menu under the pop-up menu "Custom export". 
The EndNote Export Filter will attempt to use the field endnotereftype to determine which EndNote Reference Type it should map to. Failing that, it guesses (usually pretty well -under most normal use defining this field will be unnecessary) as follows:
Mapping BibTeX entrytype -> Endnote Reference Type
	misc, other -> Generic
	unpublished -> Manuscript
	manual -> Computer Program
	article -> Journal Article
	book -> Book
	booklet -> Personal Communication
	inbook,incollection -> Book Section
	inproceedings -> Conference Proceedings
	techreport -> Report
	mastersthesis, phdthesis -> Thesis

EndNote.tab:
This is the tab-delimited spreadsheet containing a list of all the Refer codes, how they map to the Generic EndNote fields, and how the JabRef fields for the default BibTeX types are mapped to the Generic EndNote fields.

BibTeX Export to JabRef, BibTeX Export to JabRef2
These file are optional for if you wish to export EndNote entries to JabRef. They must be placed in your EndNote Styles directory. On a Mac OS X system, the default directory is /Applications/EndNote 7/Styles. On a Windows XP system, the default directory is C:\Program Files\EndNote\Styles. You may then want to open up the Style Manager (Edit->Output Styles->Open Style Manager) and add it to your Favorites.

Note that if you use EndNote as your primary manager, this export file will do a better job than the default BibTeX Export. Improvements in specific mappings are noted below. General improvements include:
All: 	Maps Custom 1-6 fields to pdf/comment/entrytype/crossref/owner/key
	Includes URL
	Includes EndNoteRefType
	Includes ShortTitle
	Includes ISBN/ISSN where appropriate

Mapping Endnote -> BibTeX (improvement over default)
	Generic -> misc (correctly maps Publisher->Howpublished)
	Journal Article -> article
	Book -> book (maps Editor,Number of Volumes)
	Book Section -> incollection (maps Section,Date,Type of Work)
	Conference Proceedings -> inproceedings (maps Organization,Edition,Date)
	Report -> techreport (maps City)
	Thesis -> phdthesis (maps City,Date)
	Magazine Article -> article
	Newspaper Article -> article (new)
	Edited Book -> book (maps Number of Volumes)
	Electronic Source -> misc (new)
	Manuscript -> unpublished (new)
	Computer Program -> manual (new)
Other EndNote Reference Types will be mapped to misc.

*********************************************************************************
Usage
*********************************************************************************
To export the entries of your database select File->Custom Export->EndNote and type in the output filename.

To import the entries into Endnote, open up a (or create a new) database. Select File->Import, then select "EndNote Import from JabRef." Click on Choose File, then select the output file you created in the previous step.

To re-export to JabRef, two EndNote Styles are provided. Select a style (see "Notes" for the problems with each), then select File->Export. The exported text file is a BibTeX file ready to be read by JabRef.

*********************************************************************************
Notes:
*********************************************************************************
The export format implemented is the EndNote Import format, an extension of the Refer format.

Only two JabRef fields are unsupported due to a lack of Custom fields in EndNote: doi and citeseerurl. Enterprising users should be able to modify the enclosed files in order to swap out two other fields (e.g. pdf and owner) instead. Note that EndNote 8 has additional fields that could be ideal for doi and citeseerurl (part of the reason why these are excluded here). In particular, Electronic Resource Number (DOI) and Link to PDF. The latter is actually a URL field, not a relative field like the pdf field in JabRef, so it would actually be better for citeseerurl than pdf. Unfortunately, ISI ResearchSoft has established no new extension of the Refer standard to include these fields, so any immediate solution would be likely to break later.

This has been tested on Mac OS X 10.3.7 and Windows XP SP2 using JabRef 1.6 and EndNote 7. It should work on EndNote 8 on either platform.

BibTeX Export to JabRef munges together some BibTeX types (e.g. inbook/incollection -> Book Section -> incollection). Use BibTeX Export to JabRef2 instead if you need better mapping - but only if you are using field Custom 3 (entrytype) to store the BibTeX entrytypes.

BibTeX Export to JabRef2 is ONLY for use if you are re-exporting a file that was imported from JabRef. This is because it uses Custom 3 (entrytype) to store and output the entrytype rather than guessing from the EndNote reference type. If this field isn't filled in, it will export bad BibTeX code. You have been warned.

*********************************************************************************
Special note on corporate authors:
*********************************************************************************
Corporate Authors (e.g. {Central Intelligence Agency} should be mapped to "Central Intelligence Agency," in EndNote, but aren't (this would require a bugfix in the reading of authors in JabRef).
This can be kludged by removing the "AuthorDate" formatter in the .layout files and adding a comma at the end of the author line; e.g. turning 
%A \format[AuthorLastFirst,RemoveBrackets]{\author}
into
%A \format[RemoveBrackets]{\author},
However, if you have any author names that are NOT in Last, First format in the first place, this will assume they are all corporate authors.

Similarly, Endnote doesn't properly output corporate authors, either. To have Endnote output corporate authors for use in BibTeX, enter them as
{Central Intelligence Agency},